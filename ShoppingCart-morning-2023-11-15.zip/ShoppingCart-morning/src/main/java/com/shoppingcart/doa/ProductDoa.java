package com.shoppingcart.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import com.shoppingcart.model.Product;

public class ProductDoa {
	private Connection con;
	private String query;
	private PreparedStatement pst;
	private ResultSet res;
	
	public ProductDoa(Connection con) {
		super();
		this.con = con;
	}
	public List<Product> getAllProducts(){
		List<Product> products = new ArrayList<Product>();
		try {
			query = "Select * from products";
			pst = this.con.prepareStatement(query);
			res = pst.executeQuery();
			while(res.next()) {
				Product row = new Product();
				row.setId(res.getInt("id"));
				row.setName(res.getString("name"));
				row.setCategory(res.getString("category"));
				row.setPrice(res.getDouble("price"));
				row.setImage(res.getString("image"));
				
				products.add(row);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	return products;
	}

}
